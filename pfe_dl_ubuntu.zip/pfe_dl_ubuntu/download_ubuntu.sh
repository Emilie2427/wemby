#!/bin/bash
# Téléchargement du corpus vidéo PFE (Ubuntu)
# Usage : ./download_ubuntu.sh
set -e
cd "$(dirname "$0")"

# Dépendances système
sudo apt update
sudo apt install -y python3-venv ffmpeg

# Environnement Python
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip yt-dlp

# Téléchargement (reprend là où il s'est arrêté si on le relance)
mkdir -p videos
yt-dlp -a videos_basket.txt \
  -f "bv*[height<=1080]+ba/b" \
  --merge-output-format mp4 \
  --ignore-errors --no-overwrites \
  --download-archive videos/.archive.txt \
  -o "videos/%(channel)s/%(title)s [%(id)s].%(ext)s"

echo "Terminé : $(find videos -name '*.mp4' | wc -l) vidéos dans ./videos"
