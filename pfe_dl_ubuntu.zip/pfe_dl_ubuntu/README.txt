Téléchargement du corpus vidéo du PFE (Ubuntu)

1. Dézipper le dossier.
2. Dans un terminal, aller dans le dossier puis lancer :
   chmod +x download_ubuntu.sh
   ./download_ubuntu.sh

Le script installe ffmpeg et python3-venv (mot de passe sudo demandé),
crée un venv, installe yt-dlp et télécharge les vidéos dans ./videos,
rangées par chaîne.

Volume attendu : exactement les 136 vidéos du corpus, environ 8,7 Go.
La liste contient les identifiants précis des vidéos (pas de chaîne ni de
playlist), donc le corpus est identique même si les chaînes publient
de nouvelles vidéos.
Si le téléchargement s'interrompt, relancer le script : les vidéos déjà
téléchargées ne sont pas refaites.
